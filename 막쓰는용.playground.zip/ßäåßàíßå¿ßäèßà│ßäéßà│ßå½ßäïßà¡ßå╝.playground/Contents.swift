

// 학점 데이터
let thisSemester: [String: Double] = ["Koko":1.77, "Mingming":2.49 , "Jiyun":4.06, "Jeongmin": 3.98, "JJanggu":3.02 ]

//1.장학생선발(평점 3.75 이상)
var highClass: [String] = []
for (student, credit) in thisSemester {
    if credit > 3.75 {
        highClass += [student]
    }
}
print(highClass)

//1. 장학생 선발 풀이
let highClass2 = thisSemester.filter{(key, value) -> Bool in
    return value >= 3.75
    } .map {(key, value) -> String in
        return key
}

print(highClass2)

//2.학사경고
var cheerupGroup: [String] = []
for (student, credit) in thisSemester {
    if credit < 2.0 {
        cheerupGroup += [student]
    }
}
print(cheerupGroup)

//2. 학사경고 문제 풀이
let cheerupGroup2 = thisSemester.filter{(key, value) -> Bool in
    return value < 2.0
    } .map {(key, value) -> String in
        return key
}

print(cheerupGroup2)


//3.string배열로 저장하기

var allstudents: [String] = []
for (student, credit) in thisSemester {
    let str = "student: " + String(credit)
    allstudents += [str]
}
print(allstudents)


// 고연전 고대전적을 통해서 연대전적 알아내기!

/*
 let yearKu : [String: Int] = ["baseball": 0, "basketball": 0, "soccer": 0, "rugby": 0, "icehockey": 0]
 var yearYs : [String: Int] = [:]
 
 
 // for 문에서 만약 yearKu 변수가 0이면 1을 더해서 yearYs에 저장하고
 // 만약 yearKu 변수가 1이면 0을 빼서 yearYs에 저장
 
 for (type, result) in yearKu{
 if (result==0) {
 append.
 }
 else
 result -=1
 }
 
 print(yearYs)
 */


// 고연전 전적 알아보기
let yearKu : [String: Int] = ["baseball": 0, "basketball": 0, "soccer": 0, "rugby": 0, "icehockey": 0]

var resultAlarm: String = ""

for (type, result) in yearKu {
    var times: Int = 0
    if result==1 {
        times += 1
    }
    resultAlarm = "이번 고연전에서 고려대학교가 이긴횟수는 \(times)번 입니다."
}
print(resultAlarm)













