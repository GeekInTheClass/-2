

// 학점 데이터
let thisSemester: [String: Double] = ["Koko":1.77, "Mingming":2.49 , "Jiyun":4.06, "Jeongmin": 3.98, "JJanggu":3.02 ]

//1.장학생선발(평점 3.75 이상)
var highClass: [String] = []
for (student, credit) in thisSemester {
    if credit > 3.75 {
        highClass += [student]
    }
}
print(highClass)


//2.학사경고
var cheerupGroup: [String] = []
for (student, credit) in thisSemester {
    if credit < 2.0 {
        cheerupGroup += [student]
    }
}
print(cheerupGroup)


//3.string배열로 저장하기

var allstudents: [String] = []
for (student, credit) in thisSemester {
    let str = "student: " + String(credit)
    allstudents += [str]
}
print(allstudents)













